#include <iostream>

#include "iem1176/Calibration.h"

int main(int argc, char** argv) {
  if (argc != 3) {
    std::cerr << "usage: iem1176_calibrate presets.json presets.calibrated.json\n";
    return 2;
  }
  try {
    iem1176::PresetFile file = iem1176::loadPresetFile(argv[1]);
    if (file.presets.size() != 24) {
      std::cerr << "expected 24 presets, got " << file.presets.size() << "\n";
      return 1;
    }
    int failed = 0;
    for (auto& preset : file.presets) {
      failed += iem1176::calibratePreset(preset, std::cout);
    }
    file.generatedAt = "2026-11-04T23:10:00Z";
    iem1176::savePresetFile(argv[2], file);
    if (failed) {
      std::cerr << failed << " preset(s) outside tolerance after 10 iterations\n";
      return 1;
    }
    std::cout << "calibration pass: " << file.presets.size() << " presets\n";
    return 0;
  } catch (const std::exception& ex) {
    std::cerr << ex.what() << "\n";
    return 1;
  }
}
