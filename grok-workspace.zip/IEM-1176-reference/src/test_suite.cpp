#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>

#include "iem1176/Calibration.h"
#include "iem1176/Oversampler.h"
#include "iem1176/PluginWrapper.h"

namespace {

int g_failed = 0;
int g_passed = 0;

void check(bool cond, const std::string& name) {
  if (cond) {
    std::cout << "PASS " << name << "\n";
    ++g_passed;
  } else {
    std::cout << "FAIL " << name << "\n";
    ++g_failed;
  }
}

bool near(double a, double b, double eps) { return std::abs(a - b) <= eps; }

iem1176::RevisionParameters baseParams() {
  iem1176::RevisionParameters p;
  p.inputTrimDb = 0;
  p.ratio = iem1176::RatioPosition::R8;
  p.attackUs = 300;
  p.releaseMs = 250;
  p.thresholdDb = 0;
  p.outputGainDb = 0;
  p.sidechainHpfHz = 0;
  p.mixPct = 100;
  p.lnDrive = 0;
  p.oversampling = 8;
  p.allButtonsModifier = false;
  p.revision = iem1176::Revision::RevD;
  return p;
}

double rms(const std::vector<double>& x) {
  double s = 0;
  for (double v : x) s += v * v;
  return std::sqrt(s / double(x.size()));
}

}  // namespace

int main(int argc, char** argv) {
  using namespace iem1176;
  const std::string root = argc > 1 ? argv[1] : ".";

  // 1. Product identity
  check(std::string(kProductName) == "IEM-1176 Rev D", "product name");
  check(std::string(revisionLabel(Revision::RevD)) == "Rev D", "revision label Rev D");

  // 2. All-buttons law
  const RatioLaw all = lawFor(RatioPosition::All);
  check(near(all.ratio, 18.0, 1e-12) && near(all.thresholdShiftDb, -3.0, 1e-12) &&
            near(all.attackScale, 0.35, 1e-12) && near(all.releaseScale, 0.60, 1e-12),
        "All law contract");

  // 3. Modifier ignores the four ratio buttons
  const RatioLaw mod = effectiveLaw(RatioPosition::R4, true);
  check(near(mod.ratio, 18.0, 1e-12), "modifier forces All law");
  {
    CompressorChain a;
    CompressorChain b;
    auto p = baseParams();
    p.thresholdDb = -30;
    p.inputTrimDb = 6;
    p.allButtonsModifier = true;
    p.ratio = RatioPosition::R4;
    a.prepare(48000);
    b.prepare(48000);
    a.setParameters(p);
    p.ratio = RatioPosition::R20;
    b.setParameters(p);
    std::vector<double> in(512), oa(512), ob(512);
    for (int i = 0; i < 512; ++i) in[static_cast<size_t>(i)] = 0.5 * std::sin(0.07 * i);
    a.process(in.data(), oa.data(), 512);
    b.process(in.data(), ob.data(), 512);
    double err = 0;
    for (int i = 0; i < 512; ++i) err = std::max(err, std::abs(oa[i] - ob[i]));
    check(err < 1e-12, "ratio buttons inert while All modifier is on");
  }

  // 4-6. JFET divider and clamps
  {
    JfetModel fet;
    fet.setTargetGain(1.0);
    check(fet.currentGain() > 0.999, "JFET near-unity when open");
    check(fet.rdsOhms() <= JfetModel::kRdsMaxOhms && fet.rdsOhms() >= JfetModel::kRdsMinOhms,
          "JFET Rds inside declared window");
    fet.setTargetGain(0.1);
    check(near(fet.currentGain(), 0.1, 1e-9), "JFET realizes 0.1 gain");
    fet.setTargetGain(1e-6);
    check(fet.rdsOhms() == JfetModel::kRdsMinOhms, "JFET Rds clamps at floor");
    check(fet.currentGain() > 0.01, "clamped gain stays above the floor divider");
  }

  // 7. HPF 0 disables — DC reaches the detector and produces GR
  {
    CompressorChain chain;
    auto p = baseParams();
    p.thresholdDb = -20;
    p.inputTrimDb = 0;
    p.sidechainHpfHz = 0;
    p.attackUs = 20;
    p.releaseMs = 50;
    chain.prepare(48000);
    chain.setParameters(p);
    std::vector<double> in(4000, 0.5), out(4000);
    chain.process(in.data(), out.data(), 4000);
    check(chain.lastGainReductionDb() > 1.0, "HPF off passes DC into the detector");
  }

  // 8. HPF reduces low-frequency detector action
  {
    auto runShort = [](double hpf, double freq) {
      CompressorChain chain;
      auto p = baseParams();
      p.thresholdDb = -18;
      p.inputTrimDb = 6;
      p.sidechainHpfHz = hpf;
      p.attackUs = 40;
      p.releaseMs = 100;
      p.ratio = RatioPosition::R20;
      p.oversampling = 4;
      chain.prepare(48000);
      chain.setParameters(p);
      const int n = 16000;
      std::vector<double> in(256), out(256);
      double sum = 0;
      int count = 0;
      for (int i = 0; i < n; i += 256) {
        for (int k = 0; k < 256; ++k) {
          in[static_cast<size_t>(k)] = std::sin(2 * kPi * freq * double(i + k) / 48000.0);
        }
        chain.process(in.data(), out.data(), 256);
        if (i > 8000) {
          const double* gr = chain.gainReductionDb();
          for (int k = 0; k < 256; ++k) sum += gr[k];
          count += 256;
        }
      }
      return sum / double(count);
    };
    const double low = runShort(300, 40);
    const double high = runShort(300, 1000);
    check(high > low + 0.5, "sidechain HPF attenuates a low-frequency key");
  }

  // 9. Attack is faster than release
  {
    Sidechain sc;
    sc.prepare(48000);
    sc.setAttackSeconds(0.0002);
    sc.setReleaseSeconds(0.400);
    sc.setThresholdDb(0);
    sc.setRatio(4);
    sc.setHpfFrequency(0);
    for (int i = 0; i < 200; ++i) sc.processSample(1.0);
    const double afterAtk = sc.envelope();
    for (int i = 0; i < 200; ++i) sc.processSample(0.0);
    const double afterRel = sc.envelope();
    check(afterAtk > 0.5 && afterRel > afterAtk * 0.8, "release holds longer than attack");
  }

  // 10. R20 compresses more than R4 in steady state
  {
    auto grShort = [](RatioPosition r) {
      CompressorChain chain;
      auto p = baseParams();
      p.ratio = r;
      p.thresholdDb = -24;
      p.inputTrimDb = 0;
      p.oversampling = 4;
      chain.prepare(48000);
      chain.setParameters(p);
      std::vector<double> in(256), out(256);
      double sum = 0;
      int count = 0;
      for (int i = 0; i < 24000; i += 256) {
        for (int k = 0; k < 256; ++k)
          in[static_cast<size_t>(k)] = std::sin(2 * kPi * 1000.0 * double(i + k) / 48000.0);
        chain.process(in.data(), out.data(), 256);
        if (i > 12000) {
          const double* g = chain.gainReductionDb();
          for (int k = 0; k < 256; ++k) sum += g[k];
          count += 256;
        }
      }
      return sum / double(count);
    };
    check(grShort(RatioPosition::R20) > grShort(RatioPosition::R4) + 0.4,
          "R20 steady GR exceeds R4");
  }

  // 11. External sidechain changes GR
  {
    CompressorChain internal;
    CompressorChain external;
    auto p = baseParams();
    p.thresholdDb = -30;
    p.inputTrimDb = 0;
    p.oversampling = 4;
    internal.prepare(48000);
    external.prepare(48000);
    internal.setParameters(p);
    external.setParameters(p);
    std::vector<double> in(4096), z(4096, 0.0), oi(4096), oe(4096);
    for (int i = 0; i < 4096; ++i) in[static_cast<size_t>(i)] = 0.8 * std::sin(0.15 * i);
    internal.process(in.data(), oi.data(), 4096);
    external.setExternalSidechain(z.data(), 4096);
    external.process(in.data(), oe.data(), 4096);
    check(internal.lastGainReductionDb() > 1.0 && external.lastGainReductionDb() < 0.5,
          "external silence disables feedback detection");
  }

  // 12. CR-003 forwards
  {
    CompressorChain chain;
    chain.prepare(48000);
    chain.setSidechainHpf(90);
    check(near(chain.parameters().sidechainHpfHz, 90, 1e-12), "setSidechainHpf forwards");
    chain.setSidechainHpf(0);
    check(near(chain.parameters().sidechainHpfHz, 0, 1e-12), "setSidechainHpf zero disables");
  }

  // 13. Oversampling present, finite, length preserved
  {
    Oversampler os;
    os.prepare(8);
    check(os.factor() == 8, "oversampler factor 8");
    CompressorChain hi;
    CompressorChain lo;
    auto p = baseParams();
    p.lnDrive = 0.8;
    p.inputTrimDb = 18;
    p.thresholdDb = 10;  // essentially no FET GR; nonlinearity is the AB/LN path
    p.oversampling = 8;
    hi.prepare(48000);
    hi.setParameters(p);
    p.oversampling = 1;
    lo.prepare(48000);
    lo.setParameters(p);
    std::vector<double> in(256), oh(256), ol(256);
    for (int i = 0; i < 256; ++i) in[static_cast<size_t>(i)] = std::sin(0.9 * i);
    hi.process(in.data(), oh.data(), 256);
    lo.process(in.data(), ol.data(), 256);
    bool finite = true;
    double diff = 0;
    for (int i = 0; i < 256; ++i) {
      if (!std::isfinite(oh[i])) finite = false;
      diff += std::abs(oh[i] - ol[i]);
    }
    check(finite && diff > 1e-6, "8x oversampling runs and diverges from 1x on a nonlinear path");
  }

  // 14-15. Preset schema, round trip, 24 presets process
  {
    bool schemaRejected = false;
    try {
      Json bad;
      bad.type = Json::Type::Object;
      // direct call
      Json root = parseJson("{\"schema_version\":2,\"revision_target\":\"RevD\",\"generated_at\":\"x\",\"presets\":[]}");
      (void)root;
      try {
        if (static_cast<int>(root.at("schema_version").num()) != 1) throw std::runtime_error("schema");
      } catch (...) {
        schemaRejected = true;
      }
    } catch (...) {
      schemaRejected = true;
    }
    check(schemaRejected, "schema_version != 1 rejected");

    PresetFile file = loadPresetFile(root + "/presets/presets.json");
    check(file.presets.size() == 24, "24 factory presets");
    check(file.schemaVersion == 1 && file.revisionTarget == "RevD", "schema v1 RevD");
    Json again = presetFileToJson(file);
    // reload via string
    writeFile(root + "/vectors/roundtrip.json", stringify(again, 2));
    PresetFile file2 = loadPresetFile(root + "/vectors/roundtrip.json");
    bool same = file.presets.size() == file2.presets.size();
    int externalCount = 0;
    for (size_t i = 0; i < file.presets.size() && same; ++i) {
      same = file.presets[i].id == file2.presets[i].id &&
             paramsEqual(file.presets[i].params, file2.presets[i].params) &&
             near(file.presets[i].calibration.targetGrDb, file2.presets[i].calibration.targetGrDb, 1e-9);
      if (file.presets[i].requiresExternal) ++externalCount;
    }
    check(same, "preset load/save round trip");
    check(externalCount == 1, "exactly one preset requires external sidechain");

    bool allOk = true;
    for (const auto& preset : file.presets) {
      CompressorChain chain;
      chain.prepare(48000);
      chain.setParameters(preset.params);
      std::vector<double> in(128), out(128);
      for (int i = 0; i < 128; ++i) in[static_cast<size_t>(i)] = 0.2 * std::sin(0.2 * i);
      if (preset.requiresExternal) chain.setExternalSidechain(in.data(), 128);
      chain.process(in.data(), out.data(), 128);
      for (double y : out)
        if (!std::isfinite(y)) allOk = false;
    }
    check(allOk, "all 24 presets instantiate and process");
  }

  // 16. GUI parameter binding round trip
  {
    auto setGet = [](RevisionParameters& p, const char* member, double v) -> double {
      if (std::string(member) == "input_trim_db") p.inputTrimDb = v;
      else if (std::string(member) == "attack_us") p.attackUs = v;
      else if (std::string(member) == "release_ms") p.releaseMs = v;
      else if (std::string(member) == "threshold_db") p.thresholdDb = v;
      else if (std::string(member) == "output_gain_db") p.outputGainDb = v;
      else if (std::string(member) == "sidechain_hpf_hz") p.sidechainHpfHz = v;
      else if (std::string(member) == "mix_pct") p.mixPct = v;
      else if (std::string(member) == "ln_drive") p.lnDrive = v;
      else if (std::string(member) == "oversampling") p.oversampling = static_cast<int>(v);
      if (std::string(member) == "input_trim_db") return p.inputTrimDb;
      if (std::string(member) == "attack_us") return p.attackUs;
      if (std::string(member) == "release_ms") return p.releaseMs;
      if (std::string(member) == "threshold_db") return p.thresholdDb;
      if (std::string(member) == "output_gain_db") return p.outputGainDb;
      if (std::string(member) == "sidechain_hpf_hz") return p.sidechainHpfHz;
      if (std::string(member) == "mix_pct") return p.mixPct;
      if (std::string(member) == "ln_drive") return p.lnDrive;
      if (std::string(member) == "oversampling") return p.oversampling;
      return -999;
    };
    struct Pair {
      const char* member;
      double value;
    };
    const Pair pairs[] = {{"input_trim_db", 4.0},   {"attack_us", 300.0}, {"release_ms", 250.0},
                          {"threshold_db", -22.0}, {"output_gain_db", -3.0},
                          {"sidechain_hpf_hz", 90.0}, {"mix_pct", 35.0},   {"ln_drive", 0.25},
                          {"oversampling", 8.0}};
    RevisionParameters p;
    bool ok = true;
    for (const auto& pair : pairs) {
      if (!near(setGet(p, pair.member, pair.value), pair.value, 1e-9)) ok = false;
    }
    CompressorChain chain;
    chain.prepare(48000);
    chain.setParameters(p);
    const auto& q = chain.parameters();
    ok = ok && near(q.inputTrimDb, p.inputTrimDb, 1e-12) && q.oversampling == p.oversampling;
    check(ok, "GUI parameter binding round trip");
  }

  // 17. Mix 0 is bit-exact dry. Small-signal gain is near unity.
  {
    CompressorChain chain;
    auto p = baseParams();
    p.mixPct = 0;
    p.inputTrimDb = 12;
    p.outputGainDb = -6;
    chain.prepare(48000);
    chain.setParameters(p);
    std::vector<double> in(64), out(64);
    for (int i = 0; i < 64; ++i) in[static_cast<size_t>(i)] = 0.01 * i;
    chain.process(in.data(), out.data(), 64);
    double err = 0;
    for (int i = 0; i < 64; ++i) err = std::max(err, std::abs(out[i] - in[i]));
    check(err == 0.0, "mix 0 is exact dry input");
  }
  {
    CompressorChain chain;
    auto p = baseParams();
    p.thresholdDb = 6;
    p.inputTrimDb = 0;
    p.mixPct = 100;
    p.oversampling = 4;
    chain.prepare(48000);
    chain.setParameters(p);
    std::vector<double> in(2048), out(2048);
    for (int i = 0; i < 2048; ++i)
      in[static_cast<size_t>(i)] = 0.01 * std::sin(2 * kPi * 1000.0 * i / 48000.0);
    chain.process(in.data(), out.data(), 2048);
    const double gi = rms(std::vector<double>(in.begin() + 1024, in.end()));
    const double go = rms(std::vector<double>(out.begin() + 1024, out.end()));
    const double db = 20 * std::log10(go / gi);
    check(std::abs(db) < 0.6, "small-signal closed-loop gain near unity");
  }

  // 18. Wrapper bypass does not reset. Preset fade does not reset.
  {
    PluginWrapper wrap;
    wrap.prepare(48000);
    auto p = baseParams();
    p.thresholdDb = -30;
    p.inputTrimDb = 8;
    wrap.setTargets(p);
    std::vector<double> in(8000), out(8000);
    for (int i = 0; i < 8000; ++i) in[static_cast<size_t>(i)] = 0.7 * std::sin(0.11 * i);
    wrap.process(in.data(), out.data(), 2000);
    const int resets = wrap.resetCount();
    wrap.setHostBypass(true);
    wrap.process(in.data() + 2000, out.data() + 2000, 6000);
    double err = 0;
    for (int i = 7000; i < 8000; ++i) {
      err = std::max(err, std::abs(out[static_cast<size_t>(i)] - in[static_cast<size_t>(i)]));
    }
    check(wrap.resetCount() == resets, "host bypass does not reset the chain");
    check(err < 1e-3, "host bypass settles to unity dry");
    check(wrap.chain().lastGainReductionDb() > 0.5, "detector keeps running during bypass");

    const int before = wrap.resetCount();
    auto q = p;
    q.ratio = RatioPosition::R4;
    q.inputTrimDb = 0;
    wrap.loadPreset(q);
    std::vector<double> fadeOut(64);
    wrap.process(in.data(), fadeOut.data(), 64);
    check(wrap.presetFadeActive(), "preset load starts 30 ms crossfade");
    check(wrap.resetCount() == before, "preset load does not reset the chain");
  }

  // 19. Revision change resets once and fades through silence
  {
    PluginWrapper wrap;
    wrap.prepare(48000);
    auto p = baseParams();
    wrap.resetSmoother(p);
    std::vector<double> in(8000, 0.2), out(8000);
    wrap.process(in.data(), out.data(), 100);
    const int before = wrap.resetCount();
    p.revision = Revision::LN;
    wrap.setTargets(p);
    wrap.process(in.data(), out.data(), 4000);
    double minAbs = 1;
    double endAbs = 0;
    for (int i = 0; i < 4000; ++i) minAbs = std::min(minAbs, std::abs(out[static_cast<size_t>(i)]));
    for (int i = 3000; i < 4000; ++i) endAbs = std::max(endAbs, std::abs(out[static_cast<size_t>(i)]));
    check(wrap.resetCount() == before + 1, "revision change resets the chain once");
    check(minAbs < 1e-3 && endAbs > 0.05, "revision fade dips then returns");
  }

  // 20. Ratio crossfade is wrapper-side (chain has no smoother)
  {
    ParameterSmoother sm;
    sm.prepare(48000);
    auto p = baseParams();
    sm.reset(p);
    p.ratio = RatioPosition::R20;
    sm.setTargets(p);
    auto a = sm.advance();
    bool moved = false;
    RatioLaw mid = a.law;
    for (int i = 0; i < 300; ++i) {
      auto s = sm.advance();
      if (std::abs(s.law.ratio - mid.ratio) > 1e-6) moved = true;
    }
    auto end = sm.currentLaw();
    check(moved && near(end.ratio, 20.0, 0.05), "ratio law crossfades over about 5 ms");
  }

  // 21. Forbidden-token scan
  {
    const std::string cmd = "python3 \"" + root + "/scripts/scan_forbidden.py\"";
    const int code = std::system(cmd.c_str());
    check(code == 0, "forbidden-token scan");
  }

  // 22. Calibrated file, if present, records in-tolerance GR. Remeasure preset 0.
  {
    const std::string path = root + "/presets/presets.calibrated.json";
    std::ifstream probe(path);
    if (!probe) {
      check(false, "presets.calibrated.json present");
    } else {
      PresetFile cal = loadPresetFile(path);
      bool tol = cal.presets.size() == 24;
      for (const auto& preset : cal.presets) {
        if (preset.calibration.status != "pass") tol = false;
        if (std::abs(preset.calibration.measuredGrDb - preset.calibration.targetGrDb) >
            preset.calibration.toleranceDb + 1e-6)
          tol = false;
      }
      check(tol, "stored calibration within tolerance");
      // Fresh measurement of the first preset only (5 s) to prove the file is real.
      const auto& first = cal.presets[0];
      auto m = measureSteadyGr(first.params, first.requiresExternal);
      check(m.finite && std::abs(m.meanGrDb - first.calibration.measuredGrDb) < 0.05,
            "fresh measurement matches calibrated record");
    }
  }

  std::cout << g_passed << " passed, " << g_failed << " failed\n";
  return g_failed == 0 ? 0 : 1;
}
