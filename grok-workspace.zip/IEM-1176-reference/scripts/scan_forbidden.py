#!/usr/bin/env python3
"""Fail if a user-facing string asset contains a forbidden standalone token."""

from __future__ import annotations

import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
TOKEN_FILE = ROOT / "assets" / "forbidden_tokens.txt"
EXTENSIONS = {
    ".json",
    ".svg",
    ".txt",
    ".md",
    ".cpp",
    ".h",
    ".ts",
    ".tsx",
    ".js",
    ".css",
    ".html",
    ".mjs",
}
SKIP_DIR_NAMES = {
    "node_modules",
    ".git",
    "dist",
    "build",
    "artifacts",
    "screenshots",
    ".grok",
}
SKIP_FILE_NAMES = {TOKEN_FILE.name}


def load_tokens() -> list[str]:
    tokens: list[str] = []
    for line in TOKEN_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        tokens.append(line)
    if not tokens:
        raise SystemExit("forbidden token list is empty")
    return tokens


def iter_files(root: pathlib.Path):
    if not root.exists():
        return
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.name in SKIP_FILE_NAMES:
            continue
        if any(part in SKIP_DIR_NAMES for part in path.parts):
            continue
        if path.suffix.lower() not in EXTENSIONS:
            continue
        yield path


def main() -> int:
    tokens = load_tokens()
    pattern = re.compile(r"\b(" + "|".join(re.escape(t) for t in tokens) + r")\b", re.IGNORECASE)
    roots = [ROOT, ROOT.parent / "src", ROOT.parent / "public"]
    failures: list[str] = []
    for root in roots:
        for path in iter_files(root):
            try:
                text = path.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            if pattern.search(text):
                failures.append(str(path))
    if failures:
        print("FORBIDDEN TOKEN MATCH")
        for item in failures:
            print(item)
        return 1
    print("forbidden-token scan: clean")
    return 0


if __name__ == "__main__":
    sys.exit(main())
