#pragma once

#include <fstream>
#include <sstream>
#include <stdexcept>

#include "JsonMini.h"
#include "RevisionParameters.h"

namespace iem1176 {

struct PresetCalibration {
  double refInputDbfs = 0;
  std::string refSignal = "1kHz_sine";
  double targetGrDb = 0;
  double toleranceDb = 1;
  double measuredGrDb = 0;
  int iterations = 0;
  std::string status;
};

struct Preset {
  std::string id;
  std::string name;
  std::string category;
  std::vector<std::string> tags;
  std::string intent;
  RevisionParameters params;
  PresetCalibration calibration;
  bool requiresExternal = false;
};

struct PresetFile {
  int schemaVersion = 1;
  std::string revisionTarget = "RevD";
  std::string generatedAt;
  std::vector<Preset> presets;
};

inline std::string readFile(const std::string& path) {
  std::ifstream in(path);
  if (!in) throw std::runtime_error("cannot read " + path);
  std::ostringstream ss;
  ss << in.rdbuf();
  return ss.str();
}

inline void writeFile(const std::string& path, const std::string& text) {
  std::ofstream out(path);
  if (!out) throw std::runtime_error("cannot write " + path);
  out << text;
}

inline RevisionParameters paramsFromJson(const Json& p) {
  RevisionParameters r;
  r.revision = Revision::RevD;
  r.inputTrimDb = p.at("input_trim_db").num();
  RatioPosition ratio;
  if (!ratioFromId(p.at("ratio").str().c_str(), ratio)) {
    throw std::runtime_error("bad ratio " + p.at("ratio").str());
  }
  r.ratio = ratio;
  r.allButtonsModifier = p.at("all_buttons_modifier").boolean();
  r.attackUs = p.at("attack_us").num();
  r.releaseMs = p.at("release_ms").num();
  r.thresholdDb = p.at("threshold_db").num();
  r.outputGainDb = p.at("output_gain_db").num();
  r.sidechainHpfHz = p.at("sidechain_hpf_hz").num();
  r.mixPct = p.at("mix_pct").num();
  r.lnDrive = p.at("ln_drive").num();
  r.oversampling = static_cast<int>(std::lround(p.at("oversampling").num()));
  return r;
}

inline Json paramsToJson(const RevisionParameters& p) {
  Json j;
  j.type = Json::Type::Object;
  auto num = [](double v) {
    Json n;
    n.type = Json::Type::Number;
    n.n = v;
    return n;
  };
  auto str = [](const std::string& s) {
    Json n;
    n.type = Json::Type::String;
    n.s = s;
    return n;
  };
  auto bo = [](bool b) {
    Json n;
    n.type = Json::Type::Bool;
    n.b = b;
    return n;
  };
  j.o.emplace("input_trim_db", num(p.inputTrimDb));
  j.o.emplace("ratio", str(ratioId(p.ratio)));
  j.o.emplace("attack_us", num(p.attackUs));
  j.o.emplace("release_ms", num(p.releaseMs));
  j.o.emplace("threshold_db", num(p.thresholdDb));
  j.o.emplace("output_gain_db", num(p.outputGainDb));
  j.o.emplace("sidechain_hpf_hz", num(p.sidechainHpfHz));
  j.o.emplace("mix_pct", num(p.mixPct));
  j.o.emplace("ln_drive", num(p.lnDrive));
  j.o.emplace("oversampling", num(p.oversampling));
  j.o.emplace("all_buttons_modifier", bo(p.allButtonsModifier));
  return j;
}

inline Preset presetFromJson(const Json& j) {
  if (j.type != Json::Type::Object) throw std::runtime_error("preset not object");
  Preset p;
  p.id = j.at("id").str();
  p.name = j.at("name").str();
  p.category = j.at("category").str();
  p.intent = j.at("intent").str();
  for (const auto& t : j.at("tags").a) p.tags.push_back(t.str());
  p.params = paramsFromJson(j.at("parameters"));
  const Json& c = j.at("calibration");
  p.calibration.refInputDbfs = c.at("ref_input_dbfs").num();
  p.calibration.refSignal = c.at("ref_signal").str();
  p.calibration.targetGrDb = c.at("target_gr_db").num();
  p.calibration.toleranceDb = c.at("tolerance_db").num();
  if (const Json* m = c.find("measured_gr_db")) p.calibration.measuredGrDb = m->num();
  if (const Json* it = c.find("iterations")) p.calibration.iterations = static_cast<int>(it->num());
  if (const Json* st = c.find("status")) p.calibration.status = st->str();
  if (const Json* req = j.find("requires_external_sidechain")) p.requiresExternal = req->boolean();
  return p;
}

inline PresetFile loadPresetFile(const std::string& path) {
  Json root = parseJson(readFile(path));
  PresetFile f;
  f.schemaVersion = static_cast<int>(std::lround(root.at("schema_version").num()));
  if (f.schemaVersion != 1) throw std::runtime_error("schema_version rejected");
  f.revisionTarget = root.at("revision_target").str();
  if (f.revisionTarget != "RevD") throw std::runtime_error("revision_target must be RevD");
  f.generatedAt = root.at("generated_at").str();
  for (const auto& item : root.at("presets").a) f.presets.push_back(presetFromJson(item));
  return f;
}

inline Json presetToJson(const Preset& p) {
  Json j;
  j.type = Json::Type::Object;
  auto str = [](const std::string& s) {
    Json n;
    n.type = Json::Type::String;
    n.s = s;
    return n;
  };
  auto num = [](double v) {
    Json n;
    n.type = Json::Type::Number;
    n.n = v;
    return n;
  };
  auto bo = [](bool b) {
    Json n;
    n.type = Json::Type::Bool;
    n.b = b;
    return n;
  };
  j.o.emplace("id", str(p.id));
  j.o.emplace("name", str(p.name));
  j.o.emplace("category", str(p.category));
  Json tags;
  tags.type = Json::Type::Array;
  for (const auto& t : p.tags) tags.a.push_back(str(t));
  j.o.emplace("tags", std::move(tags));
  j.o.emplace("intent", str(p.intent));
  j.o.emplace("parameters", paramsToJson(p.params));
  Json c;
  c.type = Json::Type::Object;
  c.o.emplace("ref_input_dbfs", num(p.calibration.refInputDbfs));
  c.o.emplace("ref_signal", str(p.calibration.refSignal));
  c.o.emplace("target_gr_db", num(p.calibration.targetGrDb));
  c.o.emplace("tolerance_db", num(p.calibration.toleranceDb));
  if (!p.calibration.status.empty()) {
    c.o.emplace("measured_gr_db", num(p.calibration.measuredGrDb));
    c.o.emplace("iterations", num(p.calibration.iterations));
    c.o.emplace("status", str(p.calibration.status));
  }
  j.o.emplace("calibration", std::move(c));
  if (p.requiresExternal) j.o.emplace("requires_external_sidechain", bo(true));
  return j;
}

inline Json presetFileToJson(const PresetFile& f) {
  Json root;
  root.type = Json::Type::Object;
  auto str = [](const std::string& s) {
    Json n;
    n.type = Json::Type::String;
    n.s = s;
    return n;
  };
  auto num = [](double v) {
    Json n;
    n.type = Json::Type::Number;
    n.n = v;
    return n;
  };
  root.o.emplace("schema_version", num(f.schemaVersion));
  root.o.emplace("revision_target", str(f.revisionTarget));
  root.o.emplace("generated_at", str(f.generatedAt));
  Json arr;
  arr.type = Json::Type::Array;
  for (const auto& p : f.presets) arr.a.push_back(presetToJson(p));
  root.o.emplace("presets", std::move(arr));
  return root;
}

inline void savePresetFile(const std::string& path, const PresetFile& f) {
  writeFile(path, stringify(presetFileToJson(f), 2));
}

inline bool paramsEqual(const RevisionParameters& a, const RevisionParameters& b, double eps = 1e-9) {
  auto near = [&](double x, double y) { return std::abs(x - y) <= eps; };
  return a.ratio == b.ratio && a.allButtonsModifier == b.allButtonsModifier &&
         a.oversampling == b.oversampling && near(a.inputTrimDb, b.inputTrimDb) &&
         near(a.attackUs, b.attackUs) && near(a.releaseMs, b.releaseMs) &&
         near(a.thresholdDb, b.thresholdDb) && near(a.outputGainDb, b.outputGainDb) &&
         near(a.sidechainHpfHz, b.sidechainHpfHz) && near(a.mixPct, b.mixPct) &&
         near(a.lnDrive, b.lnDrive);
}

}  // namespace iem1176
