#pragma once

#include <cctype>
#include <cmath>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace iem1176 {

class Json {
 public:
  enum class Type { Null, Bool, Number, String, Array, Object };

  Type type = Type::Null;
  bool b = false;
  double n = 0;
  std::string s;
  std::vector<Json> a;
  std::map<std::string, Json> o;

  const Json& at(const std::string& key) const {
    auto it = o.find(key);
    if (it == o.end()) throw std::runtime_error("missing key: " + key);
    return it->second;
  }

  const Json* find(const std::string& key) const {
    auto it = o.find(key);
    return it == o.end() ? nullptr : &it->second;
  }

  double num() const {
    if (type != Type::Number) throw std::runtime_error("expected number");
    return n;
  }
  const std::string& str() const {
    if (type != Type::String) throw std::runtime_error("expected string");
    return s;
  }
  bool boolean() const {
    if (type != Type::Bool) throw std::runtime_error("expected bool");
    return b;
  }
};

class JsonParser {
 public:
  explicit JsonParser(const std::string& in) : in_(in) {}

  Json parse() {
    skip();
    Json v = value();
    skip();
    if (i_ != in_.size()) throw std::runtime_error("trailing json");
    return v;
  }

 private:
  const std::string& in_;
  size_t i_ = 0;

  void skip() {
    while (i_ < in_.size() && std::isspace(static_cast<unsigned char>(in_[i_]))) ++i_;
  }

  char peek() {
    skip();
    if (i_ >= in_.size()) throw std::runtime_error("unexpected end");
    return in_[i_];
  }

  char get() {
    char c = peek();
    ++i_;
    return c;
  }

  Json value() {
    char c = peek();
    if (c == '{') return object();
    if (c == '[') return array();
    if (c == '"') {
      Json j;
      j.type = Json::Type::String;
      j.s = string();
      return j;
    }
    if (c == 't' || c == 'f') return boolean();
    if (c == 'n') return null();
    return number();
  }

  Json object() {
    Json j;
    j.type = Json::Type::Object;
    get();
    skip();
    if (peek() == '}') {
      get();
      return j;
    }
    while (true) {
      if (get() != '"') throw std::runtime_error("expected key");
      --i_;
      std::string key = string();
      if (get() != ':') throw std::runtime_error("expected colon");
      j.o.emplace(key, value());
      skip();
      char c = get();
      if (c == '}') break;
      if (c != ',') throw std::runtime_error("expected comma");
    }
    return j;
  }

  Json array() {
    Json j;
    j.type = Json::Type::Array;
    get();
    skip();
    if (peek() == ']') {
      get();
      return j;
    }
    while (true) {
      j.a.push_back(value());
      skip();
      char c = get();
      if (c == ']') break;
      if (c != ',') throw std::runtime_error("expected comma");
    }
    return j;
  }

  std::string string() {
    if (get() != '"') throw std::runtime_error("expected string");
    std::string o;
    while (i_ < in_.size()) {
      char c = in_[i_++];
      if (c == '"') return o;
      if (c == '\\') {
        if (i_ >= in_.size()) throw std::runtime_error("bad escape");
        char e = in_[i_++];
        if (e == '"' || e == '\\' || e == '/')
          o.push_back(e);
        else if (e == 'n')
          o.push_back('\n');
        else if (e == 't')
          o.push_back('\t');
        else
          throw std::runtime_error("unsupported escape");
      } else {
        o.push_back(c);
      }
    }
    throw std::runtime_error("unterminated string");
  }

  Json boolean() {
    Json j;
    j.type = Json::Type::Bool;
    if (in_.compare(i_, 4, "true") == 0) {
      j.b = true;
      i_ += 4;
      return j;
    }
    if (in_.compare(i_, 5, "false") == 0) {
      j.b = false;
      i_ += 5;
      return j;
    }
    throw std::runtime_error("bad bool");
  }

  Json null() {
    if (in_.compare(i_, 4, "null") != 0) throw std::runtime_error("bad null");
    i_ += 4;
    Json j;
    j.type = Json::Type::Null;
    return j;
  }

  Json number() {
    skip();
    size_t start = i_;
    if (in_[i_] == '-') ++i_;
    while (i_ < in_.size() && (std::isdigit(static_cast<unsigned char>(in_[i_])) || in_[i_] == '.' ||
                               in_[i_] == 'e' || in_[i_] == 'E' || in_[i_] == '+' || in_[i_] == '-'))
      ++i_;
    Json j;
    j.type = Json::Type::Number;
    try {
      j.n = std::stod(in_.substr(start, i_ - start));
    } catch (...) {
      throw std::runtime_error("bad number");
    }
    return j;
  }
};

inline Json parseJson(const std::string& text) { return JsonParser(text).parse(); }

inline std::string jsonEscape(const std::string& s) {
  std::string o;
  for (char c : s) {
    if (c == '"' || c == '\\') {
      o.push_back('\\');
      o.push_back(c);
    } else if (c == '\n') {
      o += "\\n";
    } else {
      o.push_back(c);
    }
  }
  return o;
}

inline void stringify(const Json& j, std::string& o, int indent, int level) {
  const auto pad = [&](int n) {
    if (indent > 0) o.append(static_cast<size_t>(n * indent), ' ');
  };
  const auto nl = [&]() {
    if (indent > 0) o.push_back('\n');
  };
  switch (j.type) {
    case Json::Type::Null:
      o += "null";
      break;
    case Json::Type::Bool:
      o += j.b ? "true" : "false";
      break;
    case Json::Type::Number: {
      std::ostringstream ss;
      ss.setf(std::ios::fmtflags(0), std::ios::floatfield);
      ss.precision(12);
      ss << j.n;
      o += ss.str();
      break;
    }
    case Json::Type::String:
      o.push_back('"');
      o += jsonEscape(j.s);
      o.push_back('"');
      break;
    case Json::Type::Array: {
      o.push_back('[');
      if (!j.a.empty()) {
        nl();
        for (size_t i = 0; i < j.a.size(); ++i) {
          pad(level + 1);
          stringify(j.a[i], o, indent, level + 1);
          if (i + 1 != j.a.size()) o.push_back(',');
          nl();
        }
        pad(level);
      }
      o.push_back(']');
      break;
    }
    case Json::Type::Object: {
      o.push_back('{');
      if (!j.o.empty()) {
        nl();
        size_t i = 0;
        for (const auto& kv : j.o) {
          pad(level + 1);
          o.push_back('"');
          o += jsonEscape(kv.first);
          o += indent > 0 ? "\": " : "\":";
          stringify(kv.second, o, indent, level + 1);
          if (++i != j.o.size()) o.push_back(',');
          nl();
        }
        pad(level);
      }
      o.push_back('}');
      break;
    }
  }
}

inline std::string stringify(const Json& j, int indent = 2) {
  std::string o;
  stringify(j, o, indent, 0);
  o.push_back('\n');
  return o;
}

}  // namespace iem1176
