#pragma once

#include <cmath>
#include <iostream>
#include <string>

#include "CompressorChain.h"
#include "PresetIo.h"

namespace iem1176 {

struct GrMeasurement {
  double meanGrDb = 0;
  bool finite = true;
};

// 1 kHz sine at 0 dBFS peak for 5 seconds. Mean FET GR from 2.0 s to 5.0 s.
// If `external` is set, the same sine is the sidechain key (preset 23 procedure).
inline GrMeasurement measureSteadyGr(const RevisionParameters& params, bool external,
                                     double sampleRate = 48000.0) {
  CompressorChain chain;
  chain.prepare(sampleRate);
  chain.reset();
  chain.setParameters(params);
  const int sr = static_cast<int>(sampleRate);
  const int total = sr * 5;
  const int block = 256;
  std::vector<double> in(static_cast<size_t>(block));
  std::vector<double> out(static_cast<size_t>(block));
  double sum = 0;
  long count = 0;
  bool finite = true;
  int idx = 0;
  while (idx < total) {
    const int n = std::min(block, total - idx);
    for (int i = 0; i < n; ++i) {
      in[static_cast<size_t>(i)] = std::sin(2.0 * kPi * 1000.0 * double(idx + i) / sampleRate);
    }
    if (external) chain.setExternalSidechain(in.data(), n);
    chain.process(in.data(), out.data(), n);
    const double* gr = chain.gainReductionDb();
    const int winA = sr * 2;
    const int winB = sr * 5;
    for (int i = 0; i < n; ++i) {
      const int t = idx + i;
      const double y = out[static_cast<size_t>(i)];
      if (!std::isfinite(y) || !std::isfinite(gr[i])) finite = false;
      if (t >= winA && t < winB) {
        sum += gr[i];
        ++count;
      }
    }
    idx += n;
  }
  GrMeasurement m;
  m.finite = finite && count > 0;
  m.meanGrDb = count ? sum / double(count) : 0;
  return m;
}

inline int calibratePreset(Preset& preset, std::ostream& log) {
  RevisionParameters p = preset.params;
  const double target = preset.calibration.targetGrDb;
  const double tol = preset.calibration.toleranceDb;
  int iter = 0;
  double measured = 0;
  for (; iter < 10; ++iter) {
    auto m = measureSteadyGr(p, preset.requiresExternal);
    measured = m.meanGrDb;
    if (!m.finite) {
      log << "FAIL " << preset.id << " non-finite output\n";
      preset.calibration.status = "fail";
      preset.calibration.measuredGrDb = measured;
      preset.calibration.iterations = iter + 1;
      preset.params.inputTrimDb = p.inputTrimDb;
      return 1;
    }
    const double err = target - measured;
    log << preset.id << " iter " << (iter + 1) << " trim " << p.inputTrimDb << " GR " << measured
        << " err " << err << "\n";
    if (std::abs(err) <= tol) {
      preset.params.inputTrimDb = p.inputTrimDb;
      preset.calibration.measuredGrDb = measured;
      preset.calibration.iterations = iter + 1;
      preset.calibration.status = "pass";
      return 0;
    }
    const double step = std::clamp(err * 0.85, -6.0, 6.0);
    const double next = std::clamp(p.inputTrimDb + step, -24.0, 24.0);
    if (next == p.inputTrimDb) break;
    p.inputTrimDb = next;
  }
  preset.params.inputTrimDb = p.inputTrimDb;
  preset.calibration.measuredGrDb = measured;
  preset.calibration.iterations = std::max(iter, 1);
  preset.calibration.status = "fail";
  log << "FAIL " << preset.id << " target " << target << " measured " << measured << "\n";
  return 1;
}

}  // namespace iem1176
